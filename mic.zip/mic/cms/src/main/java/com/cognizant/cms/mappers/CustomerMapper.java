package com.cognizant.cms.mappers;

import com.cognizant.cms.dtos.*;
import com.cognizant.cms.models.*;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface CustomerMapper {

  // Request -> Entity
  Customer toEntity(CustomerRequest request);

  // Entity -> Response
  CustomerResponse toResponse(Customer entity);

  // Value-object conversions
  FullName toEmbedded(FullNameDTO dto);
  FullNameDTO toDto(FullName name);

  Address toEmbedded(AddressDTO dto);
  AddressDTO toDto(Address address);

  
  // Partial update (ignore nulls)
  @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
  void updateEntityFromRequest(CustomerRequest request, @MappingTarget Customer entity);
}