package com.cognizant.cms.services;

import com.cognizant.cms.dtos.CustomerRequest;
import com.cognizant.cms.dtos.CustomerResponse;

public interface CustomerService {
  CustomerResponse create(CustomerRequest request);
  CustomerResponse getById(Long id);
  CustomerResponse update(Long id, CustomerRequest request);
  boolean delete(Long id);
}