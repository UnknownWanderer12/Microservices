// src/main/java/com/cognizant/addrval/controllers/AddressValidationController.java
package com.cognizant.addrval.controllers;

import com.cognizant.addrval.dtos.AddressValidationRequest;
import com.cognizant.addrval.dtos.AddressValidationResponse;
import com.cognizant.addrval.services.AddressValidationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/validation")
@RequiredArgsConstructor
public class AddressValidationController {

    private final AddressValidationService service;

    @PostMapping("/v1.0/address")
    public ResponseEntity<AddressValidationResponse> validate(@Valid @RequestBody AddressValidationRequest request) {
        AddressValidationResponse result = service.validate(request);
        return result.getIsValid()
                ? ResponseEntity.ok(result)
                : ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(result);
    }
}