package com.cognizant.addrval.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddressValidationRequest {

    @NotBlank
    private String addressType; // "permanent" | "communication"

    @NotBlank
    @Size(max = 100)
    private String city;

    @NotBlank
    @Size(max = 100)
    private String state;

    // Indian PIN example: 6 digits, first digit 1-9
    @NotBlank
    @Pattern(regexp = "^[1-9][0-9]{5}$", message = "PIN must be 6 digits (first digit 1-9)")
    private String pin;
}