package com.cognizant.addrval.services;

import com.cognizant.addrval.dtos.AddressValidationRequest;
import com.cognizant.addrval.dtos.AddressValidationResponse;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class AddressValidationService {

    
    private static final Set<String> VALID_STATES = Set.of(
        "Tamil Nadu", "Karnataka", "Kerala", "Maharashtra", "Telangana", "Andhra Pradesh", "Delhi"
    );

    public AddressValidationResponse validate(AddressValidationRequest req) {

        
        if (!VALID_STATES.contains(req.getState())) {
            return AddressValidationResponse.builder()
                    .isValid(false)
                    .message("Unsupported state: " + req.getState())
                    .build();
        }

        


        return AddressValidationResponse.builder()
                .isValid(true)
                .message("Valid " + req.getAddressType() + " address")
                .build();
    }
}