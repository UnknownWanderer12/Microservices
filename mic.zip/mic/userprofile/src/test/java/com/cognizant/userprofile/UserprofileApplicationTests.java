package com.cognizant.userprofile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserprofileApplicationTests {

	@Test
	void contextLoads() {
	}

}
